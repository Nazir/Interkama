﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.Odbc;

namespace OTRS
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //
        }

        private void button_OpenFileToImport_Click(object sender, EventArgs e)
        {
            openFileDialogToImport.FileName = textBoxFileToImport.Text;
            if(openFileDialogToImport.ShowDialog() == DialogResult.OK)
            {
                textBoxFileToImport.Text = openFileDialogToImport.FileName;
            }
        }

        private void buttonExportToCVSwithNotes_Click(object sender, EventArgs e)
        {
            
            // В формат CVS с примечаниями

            string FileToImport = textBoxFileToImport.Text;
            if (!DESI.DESI.InitXML(FileToImport))
            {
                string sTemp = "Файл для импорта «" + FileToImport + "» не найден!";
                //Logger.Log.SaveLog("Main", sTemp, "err");
                MessageBox.Show(sTemp, "Критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //MessageBox.Show(DESI.DESI.GetValue("Row", ""));
            //textBox1.Text = DESI.DESI.GetValue("", "", 0);
            textBox1.Text = DESI.DESI.GetCSV("");
            //textBox1.Text = DESI.DESI.Test();

            
        }

        private void button_ClearTags_Click(object sender, EventArgs e)
        {

            string FileToImport = textBoxFileToImport.Text;
            if (!File.Exists(FileToImport))
            {
                string sTemp = "Файл для импорта «" + FileToImport + "» не найден!";
                MessageBox.Show(sTemp, "Критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string Result = "";
            using (StreamReader sr = File.OpenText(FileToImport))
            {
                string s = "";
                int index = -1;
                while ((s = sr.ReadLine()) != null)
                {
                    index = s.IndexOf("<?mso-application progid=\"Excel.Sheet\"?>");
                    if (index != -1)
                    {
                        s = s.Replace("<?mso-application progid=\"Excel.Sheet\"?>", "");
                    }

                    index = s.IndexOf("<ExcelWorkbook");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf("</ExcelWorkbook>", index) - index), "");
                        s = s.Replace("</ExcelWorkbook>", "");
                    }

                    index = s.IndexOf("<OfficeDocumentSettings");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf("</OfficeDocumentSettings>", index) - index), "");
                        s = s.Replace("</OfficeDocumentSettings>", "");
                    }

                    index = s.IndexOf("<Styles>");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf("</Styles>", index) - index), "");
                        s = s.Replace("</Styles>", "");
                    }

                    index = s.IndexOf("<Colors>");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf("</Colors>", index) - index), "");
                        s = s.Replace("</Colors>", "");
                    }

                    index = s.IndexOf("<x:WorksheetOptions/>");
                    if (index != -1)
                    {
                        s = s.Replace("<x:WorksheetOptions/>", "");
                    }

                    index = s.IndexOf("<");
                    if (index != -1)
                    {
                        s = s.Replace("<", "\r\n<");
                    }

                    index = s.IndexOf("ss:");
                    if (index != -1)
                    {
                        s = s.Replace("ss:", "");
                    }


                    s = s.Trim();
                    if (s != String.Empty)
                        Result += s + "\r\n";
                }
            }
            using (StreamWriter sw = File.CreateText(FileToImport + ".tmp"))
            {
                sw.Write(Result);
            }

            Result = "";
            using (StreamReader sr = File.OpenText(FileToImport + ".tmp"))
            {
                string s = "";
                int index = -1;
                while ((s = sr.ReadLine()) != null)
                {

                    index = s.IndexOf("<Workbook");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf(">", index + 1) - index + 1), "");
                    }


                    index = s.IndexOf("<Font");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf(">", index + 1) - index + 1), "");
                    }

                    index = s.IndexOf("<Column ");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf(">", index + 1) - index + 1), "");
                    }

                    index = s.IndexOf("<Row Height=\"");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf("\"", index + 12 + 1) - index + 1), "<Row");
                    }

                    index = s.IndexOf("<Data xmlns=\"");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf("\"", index + 12 + 1) - index + 1), "<Data");
                    }
                    

                    index = s.IndexOf("<Worksheet ");
                    if (index != -1)
                    {
                        s = s.Replace(s.Substring(index, s.IndexOf(">", index + 1) - index + 1), "");
                    }

                    index = s.IndexOf("</Worksheet>");
                    if (index != -1)
                    {
                        s = s.Replace("</Worksheet>", "");
                    }

                    index = s.IndexOf("</Workbook>");
                    if (index != -1)
                    {
                        s = s.Replace("</Workbook>", "");
                    }

                    index = s.IndexOf("</Font>");
                    if (index != -1)
                    {
                        s = s.Replace("</Font>", "");
                    }
                    index = s.IndexOf("<B>");
                    if (index != -1)
                    {
                        s = s.Replace("<B>", "");
                    }
                    index = s.IndexOf("</B>");
                    if (index != -1)
                    {
                        s = s.Replace("</B>", "");
                    }

                    index = s.IndexOf("T00:00:00.000");
                    if (index != -1)
                    {
                        s = s.Replace("T00:00:00.000", "");
                    }
                    
                    index = s.IndexOf(" StyleID=");
                    if (index != -1)
                    {
                        for (int i = 1; i <= 50; i++)
                        {
                            s = s.Replace(" StyleID=\"ce" + i.ToString() + "\"", "");
                        }
                    }
                    
                    index = s.IndexOf("<Cell Index=\"1024\"/>");
                    if (index != -1)
                    {
                        s = s.Replace("<Cell Index=\"1024\"/>", "");
                    }
                    /*
                    index = s.IndexOf("<Cell Index=\"");
                    if (index != -1)
                    {
                        index = s.IndexOf("<Cell Index=\"5\"/>");
                        if (index != -1)
                        {
                            s = s.Replace("<Cell Index=\"5\"/>", "<Cell><Data>NULL</Data>\r\n</Cell>");
                        }
                        else
                        {
                            index = s.IndexOf("<Cell Index=\"3\"/>");
                            if (index != -1)
                            {
                                s = s.Replace("<Cell Index=\"3\"/>", "<Cell><Data>NULL</Data>\r\n</Cell>");
                            } 
                            else
                            {
                                index = s.IndexOf("<Cell Index=\"4\"/>");
                                if (index != -1)
                                {
                                    s = s.Replace("<Cell Index=\"4\"/>", "<Cell><Data>NULL</Data>\r\n</Cell>");
                                }
                                else
                                    s = s.Replace("<Cell Index=\"", "<Cell><Data>NULL</Data>\r\n</Cell>\r\n<Cell Index=\"");
                            }
                        }
                    } //*/

                    s = s.Trim();
                    if (s != String.Empty)
                        Result += s + "\r\n";
                }
            }
            Result = Result.Replace("<Cell/>\r\n", "<Cell><Data>NULL</Data>\r\n</Cell>");
            Result = Result.Replace("<Cell Index=\"1024\"/>\r\n", "");
            Result = Result.Replace(" Height=\"12.8409\"", "");
            Result = Result.Replace("<Row>\r\n</Row>\r\n", "");
            Result = Result.Replace("<Row Index=\"65536\" Height=\"12.8409\">\r\n</Row>\r\n", "");
            using (StreamWriter sw = File.CreateText(FileToImport + ".xml"))
            {
                sw.Write(Result);
            }
            
            MessageBox.Show("OK");

        }

        private void buttonODBC_Click(object sender, EventArgs e)
        {
            OdbcConnectionStringBuilder builder =
                new OdbcConnectionStringBuilder();
            builder.Clear();
            // {Client Access ODBC Driver (32-bit)};System=my_system_name;Uid=myUserName;Pwd=myPwd"
            builder.Dsn = "otrs";
            string ConnectionString = builder.ConnectionString;
            string Temp = String.Empty;

            using (OdbcConnection connection = new OdbcConnection(ConnectionString))
            {
                string queryString = String.Empty;
                OdbcCommand command = new OdbcCommand();
                command.Connection = connection;
                //command.CommandType = CommandType.StoredProcedure;
                queryString = "SELECT * FROM general_catalog;";
                command.CommandText = queryString;
                command.Parameters.Clear();
                //command.Parameters.Add("iUnit", OdbcType.Char, 3).Value = EqUnit;
                //command.Parameters["iUnit"].Direction = ParameterDirection.Input;
                OdbcDataReader reader;
                try
                {
                    connection.Open();
                    command.Prepare();
                    command.Prepare();
                    reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                    if (reader.HasRows)
                    {
                        for (int iCounter = 0; iCounter < reader.FieldCount; iCounter++)
                        {
                            richTextBox_ODBC.Text += reader.GetName(iCounter);
                            richTextBox_ODBC.Text += "\t";
                        }
                        richTextBox_ODBC.Text += "\r\n";
                        while (reader.Read())
                        {
                            for (int iCounter = 0; iCounter < reader.FieldCount; iCounter++)
                            {
                                if (reader.IsDBNull(iCounter))
                                    richTextBox_ODBC.Text += "NULL";
                                else
                                    richTextBox_ODBC.Text += reader.GetValue(iCounter).ToString();
                                richTextBox_ODBC.Text += "\t";
                                
                            }
                            richTextBox_ODBC.Text += "\r\n";
                        }

                    }
                    command.Cancel();
                    connection.Close();
                }
                catch (InvalidOperationException exc)
                {
                    Temp = exc.ToString();
                    MessageBox.Show(Temp);
                    // SaveLog("Ошибка (InvalidOperationException): «" + Temp + "»", "RUN_5", "err", true, false, false, -1);
                   // SaveLog("Ошибка подключения!!! Обратитесь к разработчикам!", "RUN_5", "err", false, true, false, -1);
                }
                catch (Exception exc)
                {
                    Temp = exc.ToString();
                    MessageBox.Show(Temp);
                    //SaveLog("Ошибка (Exception): «" + Temp + "»", "RUN_5", "err", true, false, false, -1);
                   // SaveLog("Ошибка подключения!!! Обратитесь к разработчикам!", "RUN_5", "err", false, true, false, -1);
                }
            }

        }
    }
}
