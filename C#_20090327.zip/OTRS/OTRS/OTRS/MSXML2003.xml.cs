﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace DESI
{
    class DESI
    {
        public static string FileXML;
        public static XmlDocument xd;
        public static string RootNode = "//Table";
        public static string Slash = "/";
        public static string DataNode = "";

        public static bool InitXML(string FileName)
        {
            FileXML = FileName;
            if (!File.Exists(FileXML))
                return false;

            xd = new XmlDocument();
            xd.Load(FileXML);
            return true;
        }

        public static string Test()
        {
            string reader_xpath = String.Empty;
            string Result = String.Empty;
            XmlTextReader reader = null;

            try
            {
                //*
                String xmlFrag = String.Empty;
                using (StreamReader sr = new StreamReader(FileXML))
                {
                    xmlFrag = sr.ReadToEnd().ToString();
                }
                //*/
                /*
                // Create the string containing the XML to read.
                    String xmlFrag = "<book>" +
                           "<title>Pride And Prejudice</title>" +
                           "<author>" +
                           "<first-name>Jane</first-name>" +
                           "<last-name>Austen</last-name>" +
                           "</author>" +
                           "<curr:price>19.95</curr:price>" +
                           "<misc>&h;</misc>" +
                           "</book>";

                //*/
                // Create an XmlNamespaceManager to resolve namespaces.
                NameTable nt = new NameTable();
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(nt);
                nsmgr.AddNamespace(String.Empty, "urn:samples"); //default namespace
                //nsmgr.AddNamespace("curr", "urn:samples:dollar");
                nsmgr.AddNamespace("ss", "urn:name");

                // Create an XmlParserContext.  The XmlParserContext contains all the information
                // required to parse the XML fragment, including the entity information and the
                // XmlNamespaceManager to use for namespace resolution.
                XmlParserContext context;
                String subset = "<!ENTITY h 'hardcover'>";
                context = new XmlParserContext(nt, nsmgr, "Workbook", null, null, subset, null, null, XmlSpace.None);

                // Create the reader.
                reader = new XmlTextReader(xmlFrag, XmlNodeType.Element, context);

                // Parse the file and display the node values.
                string LastName = String.Empty;
                string readerValue = String.Empty;
                string reader_Row = String.Empty;
                string reader_Row_Cell = String.Empty;
                string reader_Row_Cell_Data = String.Empty;
                string reader_Row_Cell_Comment = String.Empty;
                string reader_Row_Cell_Comment_Data = String.Empty;
                string reader_Row_Cell_Comment_Data_Font = String.Empty;

                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        if (reader.LocalName == "Worksheet")
                            reader_xpath = String.Empty;
                        if (reader_xpath == "Worksheet/Table/Column")
                            reader_xpath = "Worksheet/Table";
                        if (reader_xpath != String.Empty)
                            reader_xpath += "/";
                        reader_xpath += reader.LocalName;
                        /*
                        if (reader.Prefix == String.Empty)
                            Result += "<" + reader.LocalName + ">";
                        else
                        {
                            Result += "<" + reader.Prefix + ":" + reader.LocalName + ">";
                            Result += "\r\n The namespace URI is " + reader.NamespaceURI + "\r\n";
                        }
                        //*/
                    }
                    //*
                    readerValue = String.Empty;
                    if (reader.HasValue)
                    {
                        readerValue = reader.Value;
                        if (reader_xpath == "Worksheet/Table/Row/Cell/Data")
                        {
                            reader_xpath = "Worksheet/Table";
                            //if (LastName == "Data")
                            Result += "\"" + readerValue + "\";";
                            //if (LastName == "Font")
                            //  Result += "\"" + readerValue + "\";";
                        }
                    }
                    //if (reader.NodeType == XmlNodeType.Text)
                    //{
                    //}
                    //else
                    //  Result += reader.NodeType + " [" + reader.Name + "]" + "\r\n";
                    if ((LastName == "Row") && reader.HasValue)
                        Result += "\r\n";
                    LastName = reader.Name;
                    //*/
                }
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }
            return Result;
        }

        public static string GetRootAttribute(string AttributeName)
        {
            try
            {
                XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode);
                return xn.Attributes[AttributeName].Value;
            }
            catch
            {
                return "Error: Attribute [" + AttributeName + "] not found!";
            }
        }

        public static string GetValue(string ValueName, string Node)
        {
            if (Node != "")
                Node += Slash;

            if (Node == "")
                Node = DataNode + Slash;

            string Result = "";

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node + ValueName);

            Result = xn.InnerText;
            if (xn.HasChildNodes)
            {
                if (xn.FirstChild.NodeType == XmlNodeType.CDATA)
                    Result = xn.FirstChild.InnerText;
            }
            return Result;
        }

        public static string GetCSV(string Node)
        {
            /* if (Node != "")
                Node += Slash; //*/

            if (Node == "")
                Node = DataNode;

            string Result = String.Empty;
            string Comment = String.Empty;
            string CellData = String.Empty;
            string TextDivider = "\"";
            string CellDivider = ";";

            int CellCounter = 0;

            //XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node);
            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode);
            if (xn.HasChildNodes)
            {
                for (int RowCounter = 0; RowCounter < xn.ChildNodes.Count; RowCounter++)
                {
                    string[] Cells = new string[6];

                    for (int i = 0; i <= 5; i++)
                    {
                        Cells[i] = "NULL";
                    }

                    Comment = String.Empty;
                    if (xn.ChildNodes[RowCounter].HasChildNodes)
                    {
                        for (CellCounter = 0; CellCounter < xn.ChildNodes[RowCounter].ChildNodes.Count; CellCounter++)
                        {
                            CellData = String.Empty;
                            int CellIndex = -1;
                            if (xn.ChildNodes[RowCounter].ChildNodes[CellCounter].Attributes.Count > 0)
                            {
                                CellIndex = Convert.ToInt16(xn.ChildNodes[RowCounter].ChildNodes[CellCounter].Attributes["Index"].Value.ToString());
                                if (CellCounter < CellIndex - 1)
                                {
                                    Result += TextDivider + "NULL" + TextDivider + CellDivider;

                                }
                            }//*/
                            Result += TextDivider;
                            if (xn.ChildNodes[RowCounter].ChildNodes[CellCounter].HasChildNodes)
                            {
                                
                                if (xn.ChildNodes[RowCounter].ChildNodes[CellCounter].FirstChild.Name == "Data")
                                {
                                    if (xn.ChildNodes[RowCounter].ChildNodes[CellCounter].FirstChild.NodeType == XmlNodeType.CDATA)
                                        CellData = xn.ChildNodes[RowCounter].ChildNodes[CellCounter].FirstChild.FirstChild.InnerText;
                                    else
                                        CellData = xn.ChildNodes[RowCounter].ChildNodes[CellCounter].FirstChild.InnerText;
                                    CellData = CellData.Replace("13\"", "13''");
                                    CellData = CellData.Replace("14\"", "14''");
                                    CellData = CellData.Replace("15\"", "15''");
                                    CellData = CellData.Replace("17\"", "17''");
                                    CellData = CellData.Replace("19\"", "19''");
                                    CellData = CellData.Replace("\"", "'");
                                    CellData = CellData.Trim();
                                    Cells[CellCounter] = CellData;
                                }
                                if (xn.ChildNodes[RowCounter].ChildNodes[CellCounter].HasChildNodes)
                                {
                                    if (xn.ChildNodes[RowCounter].ChildNodes[CellCounter].ChildNodes.Count > 1)
                                        if (xn.ChildNodes[RowCounter].ChildNodes[CellCounter].ChildNodes[1].Name == "Comment")
                                        {
                                            if (xn.ChildNodes[RowCounter].ChildNodes[CellCounter].ChildNodes[1].FirstChild.NodeType == XmlNodeType.CDATA)
                                                Comment = xn.ChildNodes[RowCounter].ChildNodes[CellCounter].ChildNodes[1].FirstChild.FirstChild.InnerXml;
                                            else
                                                Comment = xn.ChildNodes[RowCounter].ChildNodes[CellCounter].ChildNodes[1].FirstChild.InnerXml;
                                            Comment = Comment.Replace("13\"", "13''");
                                            Comment = Comment.Replace("14\"", "14''");
                                            Comment = Comment.Replace("15\"", "15''");
                                            Comment = Comment.Replace("17\"", "17''");
                                            Comment = Comment.Replace("19\"", "19''");
                                            Comment = Comment.Replace("\"", "'");
                                            Comment = Comment.Trim();
                                        }
                                }
                            }
                            if (CellData == String.Empty)
                                CellData = "NULL";
                            Result += CellData;
                            Result += TextDivider;
                            Result += CellDivider;
                        }
                    }
                    //if (Comment == String.Empty)
                        //Comment = "NULL";
                    if (Comment != String.Empty)
                    {
                        Comment = TextDivider + Comment + TextDivider;
                        Result += Comment;
                    }
                    Result += "\r\n";

                }
            }
            return Result;
        }

        public static string GetValue(string ValueName, string Node, int Index)
        {
            /* if (Node != "")
                Node += Slash; //*/

            string Result = String.Empty;

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node);
            if (xn.HasChildNodes)
            {
                if (ValueName == String.Empty)
                {
                    if (xn.ChildNodes[Index].NodeType == XmlNodeType.CDATA)
                        Result = xn.ChildNodes[Index].FirstChild.InnerText;
                    else
                        Result = xn.ChildNodes[Index].InnerText;
                 }
                else
                if (xn.ChildNodes[Index].HasChildNodes)
                {
                    for (int iCounter = 0; iCounter < xn.ChildNodes[Index].ChildNodes.Count; iCounter++)
                    {
                        if (xn.ChildNodes[Index].ChildNodes[iCounter].Name == ValueName)
                        {
                            if (xn.ChildNodes[Index].ChildNodes[iCounter].NodeType == XmlNodeType.CDATA)
                                Result = xn.ChildNodes[Index].ChildNodes[iCounter].FirstChild.InnerText;
                            else
                                Result = xn.ChildNodes[Index].ChildNodes[iCounter].InnerText;
                            break;
                        }
                    }
                }
            }
            return Result;
        }

        public static string GetValue(string ValueName, string Node, string AttributeName, string AttributeValue)
        {
            /*if (Node != "")
                Node += Slash; //*/

            string Result = "";

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node);
            if (xn.HasChildNodes)
            for (int iCounter = 0; iCounter < xn.ChildNodes.Count; iCounter++)
            {
                if (xn.ChildNodes[iCounter].Name == ValueName)
                {
                    if (xn.ChildNodes[iCounter].Attributes[AttributeName].InnerText == AttributeValue)
                    {
                        if (xn.ChildNodes[iCounter].NodeType == XmlNodeType.CDATA)
                            Result = xn.ChildNodes[iCounter].FirstChild.InnerText;
                        else 
                            Result = xn.ChildNodes[iCounter].InnerText;
                        break;
                    }
                }
            }
            return Result;
        }

        public static string GetChildValue(string ChildValueName, string Node, string AttributeName, string AttributeValue)
        {
            /*if (Node != "")
                Node += Slash;*/

            string Result = "";

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node);
            if (xn.HasChildNodes)
                for (int iCounter = 0; iCounter < xn.ChildNodes.Count; iCounter++)
                {
                    if (xn.ChildNodes[iCounter].Name == ChildValueName)
                    {
                        if (xn.Attributes[AttributeName].InnerText == AttributeValue)
                        {
                            if (xn.ChildNodes[iCounter].NodeType == XmlNodeType.CDATA)
                                Result = xn.ChildNodes[iCounter].FirstChild.InnerText;
                            else
                                Result = xn.ChildNodes[iCounter].InnerText;
                            return Result;
                        }
                    }
                }
            return Result;
        }

        public static int GetChildNodesCount(string ValueName, string Node)
        {
            if (Node != "")
                Node += Slash;

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node + ValueName);
            if (xn.HasChildNodes)
            {
                if (xn.FirstChild.NodeType != XmlNodeType.CDATA)
                    return xn.ChildNodes.Count;
            }
            return 0;
        }

        public static int GetIntValue(string ValueName, string Node)
        {
            string Result = GetValue(ValueName, Node);
            if (Result == "")
                Result = "-1";
            return Convert.ToInt32(Result);
        }

        public static bool GetBooleanValue(string ValueName, string Node)
        {
            string Result = GetValue(ValueName, Node);
            if (Result == "")
                Result = "-1";
            return Convert.ToBoolean(Result);
        }

        public static string GetAttribute(string AttributeName, string ValueName, string Node)
        {
            if (Node != "")
                Node += Slash;

            string Result = "";

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node + ValueName);
            if (xn.Attributes.Count != 0)
                Result = xn.Attributes[AttributeName].InnerText;

            return Result;
        }

        public static string GetAttribute(string AttributeName, string ValueName, string Node, int Index)
        {
            /* if (Node != "")
                Node += Slash; //*/

            string Result = String.Empty;

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node);
            if (xn.HasChildNodes)
            {
                if (ValueName == String.Empty)
                {
                    Result = xn.ChildNodes[Index].Attributes[AttributeName].Value;
                }
                else
                    if (xn.ChildNodes[Index].HasChildNodes)
                    {
                        for (int iCounter = 0; iCounter < xn.ChildNodes[Index].ChildNodes.Count; iCounter++)
                        {
                            if (xn.ChildNodes[Index].ChildNodes[iCounter].Name == ValueName)
                            {
                                Result = xn.ChildNodes[Index].ChildNodes[iCounter].Attributes[AttributeName].Value;
                                break;
                            }
                        }
                    }
            }
            return Result;            /*
            for (int iCounter = 0; iCounter < xn.ChildNodes.Count; iCounter++)
            {
                if (xn.ChildNodes[iCounter].Attributes["name"].Value == api)
                    return xn.ChildNodes[iCounter].Attributes[AttributeName].Value;
            }*/
            //return "Error: Attribute [" + AttributeName + "] not found!";
        }

        public static bool GetBooleanAttribute(string AttributeName, string ValueName, string Node)
        {
            if (Node != "")
                Node += Slash;

            string Result = "";

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node + ValueName);
            if (xn.Attributes.Count == 0)
                return false;
            else
                Result = xn.Attributes[AttributeName].InnerText;

            return Convert.ToBoolean(Result);
        }

        public static string GetFieldsValue(string ProcedureName, string FieldName, string ValueName)
        {
            string Result = "";

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode);
            if (xn.HasChildNodes)
            for (int iCounter = 0; iCounter < xn.ChildNodes.Count; iCounter++)
            {
                if (xn.ChildNodes[iCounter].Name == "Procedure")
                {
                    if (xn.ChildNodes[iCounter].Attributes["name"].Value == ProcedureName)
                    {
                        XmlNode xn_fileds = xn.ChildNodes[iCounter].SelectSingleNode("ResultFileds");
                        for (int i = 0; i < xn_fileds.ChildNodes.Count; i++)
                        {
                            XmlNode xn_field = xn_fileds.ChildNodes[i];
                            if ((xn_field.Name == "Field") && (xn_field.Attributes["name"].Value == FieldName))
                            for (int j = 0; j < xn_field.ChildNodes.Count; j++)
                            {
                                XmlNode xn_values = xn_field.ChildNodes[j];
                                if (xn_values.Name == ValueName)
                                {
                                    Result = xn_values.InnerText;
                                    return Result;
                                }
                            }
                        }
                    }
                }
            }
            return Result;
        }
    }
}
