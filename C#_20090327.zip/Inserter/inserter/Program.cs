﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;

namespace inserter
{
    class Program
    {
        public static string FileXML;
        public static XmlDocument xd;
        public static string RootNode = "//inserter";
        public static string Slash = "/";

        public static void WriteMsg(string Msg, bool bReadKey)
        {
            System.Console.WriteLine(Msg);
            if (bReadKey)
                System.Console.ReadKey();
        }

        public static string GetValue(string ValueName, string Node)
        {
            if (Node != "")
                Node += Slash;

            string Result = "";

            XmlNode xn = xd.DocumentElement.SelectSingleNode(RootNode + Slash + Node + ValueName);
            Result = xn.InnerText;
            if (xn.HasChildNodes)
            {
                if (xn.FirstChild.NodeType == XmlNodeType.CDATA)
                    Result = xn.FirstChild.Value.ToString();
            }
            return Result;
        }

        static void Main(string[] args)
        {
            try
            {
                if (args.Length > 0)
                {
                    string fileName = args[0].ToString();
                    if (File.Exists(fileName))
                    {
                        String[] arguments = Environment.GetCommandLineArgs();

                        FileInfo fi = new FileInfo(arguments[0]);
                        string AppPath = fi.DirectoryName + @"\";
                        FileXML = AppPath;
                        if (args.Length > 1)
                            FileXML += args[1].ToString();
                        else
                            FileXML += "inserter.xml";
                        if (!File.Exists(FileXML))
                        {
                            WriteMsg("Error: XML-file \"" + FileXML + "\" not found!", true);
                        }
                        else
                        {
                            string Result = "";
                            xd = new XmlDocument();
                            xd.Load(FileXML);
                            string ResultEncoding = "cp866";

                            string textTop = GetValue("textTop", "");
                            StreamReader srTop = new System.IO.StreamReader(AppPath + textTop, Encoding.GetEncoding(ResultEncoding));
                            textTop = srTop.ReadToEnd().ToString();
                            string textBottom = GetValue("textBottom", "");
                            StreamReader srBottom = new System.IO.StreamReader(AppPath + textBottom, Encoding.GetEncoding(ResultEncoding));
                            textBottom = srBottom.ReadToEnd().ToString();
                            string textUp = GetValue("textUp", "");
                            StreamReader srUp = new System.IO.StreamReader(AppPath + textUp, Encoding.GetEncoding(ResultEncoding));
                            textUp = srUp.ReadToEnd().ToString();
                            string textDown = GetValue("textDown", "");
                            StreamReader srDown = new System.IO.StreamReader(AppPath + textDown, Encoding.GetEncoding(ResultEncoding));
                            textDown = srDown.ReadToEnd().ToString();
                            System.Console.WriteLine("Info: Opening file \"" + fileName + "\".");
                            FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.ReadWrite, FileShare.None);

                            StreamReader sr = new System.IO.StreamReader(fs, Encoding.GetEncoding(ResultEncoding));
                            int iCounter = 0;
                            while (sr.Peek() >= 0)
                            {
                                iCounter++;
                                string sTemp = sr.ReadLine();
                                Console.Write(iCounter.ToString() + "  ");
                                if (sTemp.IndexOf(textUp) != -1)
                                {
                                    if (iCounter > 1)
                                        Result += "\r\n";
                                    Result += textTop;
                                }
                                Result += "\r\n" + sTemp;
                                if (sTemp.IndexOf(textDown) != -1)
                                {
                                    Result += "\r\n" + textBottom;
                                }
                            }
                            sr.Close();
                            /*
                            StreamWriter sw = new System.IO.StreamWriter(fs, System.Text.Encoding.GetEncoding("cp866"));
                            sw.Write(Result);
                            sw.Flush();
                            sw.Close();
                            */
                            if (File.Exists(fileName))
                            {
                                File.Delete(fileName);
                            }
                            using (StreamWriter sw = new StreamWriter(fileName, false, Encoding.GetEncoding(ResultEncoding)))
                            {
                                sw.Write(Result);
                                //sw.Write("\x0C"); // погон листа
                            }

                            //System.Console.ReadKey();
                        }
                    }
                    else
                    {
                        WriteMsg("Error: File \"" + fileName + "\" not found!", true);
                    }
                    
                }
                else
                {
                    WriteMsg("Error: No arguments!!!", true);
                }
            }
            catch (Exception e)
            {
                WriteMsg("Error: " + e.ToString(), true);
            }
        }
    }
}
