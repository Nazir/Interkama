﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("EQ Gate - Нижнекамск")]
[assembly: AssemblyDescription("Разработчик: Хуснудинов Назир Каримович")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ОАО «Ак Барс» Банк «Интеркама»")]
[assembly: AssemblyProduct("Equation Gate - Нижнекамск")]
[assembly: AssemblyCopyright("©  2008. Все права соблюдены.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("f6476bb5-fd0d-470b-a7de-3c22141701be")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
[assembly: NeutralResourcesLanguageAttribute("ru")]
